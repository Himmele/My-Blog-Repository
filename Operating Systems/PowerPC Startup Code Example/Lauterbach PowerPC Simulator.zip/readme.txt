Dear User,

The software and the setup program are ONLY for Windows95, Windows98 
or Windows NT 4.0. The program t32mppc.exe will not run on Windows 3.X!

RTOS and Case Tool support files are not included in the demo package.

The HELP command (or button) provides access to the online manuals.
The manual is reduced version of the full online manual.
The "Simulator Tutorial" chapter helps to make the first steps.

For updates and new versions of this debugger please check in 

http://www.lauterbach.com.


Best Regards

The Lauterbach Team
