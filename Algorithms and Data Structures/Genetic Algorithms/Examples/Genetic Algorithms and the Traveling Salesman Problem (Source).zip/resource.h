//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TSPApp.rc
//
#define IDD_MAIN                        101
#define IDD_BAR                         102
#define IDR_MENU1                       103
#define IDD_NEW                         104
#define IDD_ABOUTBOX                    105
#define IDR_RT_GIF1                     107
#define IDI_ICON2                       110
#define IDC_EDIT_COEVOLUTION            1002
#define IDC_EDIT_POPULATION             1003
#define IDC_EDIT_MUTATION               1004
#define IDC_EDIT_ELITE                  1005
#define IDC_SPIN_COEVOLUTION            1006
#define IDC_SPIN_POPULATION             1007
#define IDC_SPIN_MUTATION               1008
#define IDC_SPIN_ELITE                  1009
#define IDC_START                       1010
#define IDC_STOP                        1011
#define IDC_RESET                       1012
#define IDC_FRAME                       1014
#define IDC_CLEAR                       1015
#define IDC_EDIT_MIGRATION              1016
#define IDC_SPIN_MIGRATION              1017
#define IDC_EDIT_CROSSOVER              1018
#define IDC_SPIN_CROSSOVER              1019
#define IDC_BOARD                       1020
#define IDC_EDIT_HEURISTICS             1020
#define IDC_CHECK_ELTWINS               1021
#define IDC_SPIN_HEURISTICS             1022
#define IDC_EDIT_POINTS                 1023
#define IDC_SPIN_POINTS                 1024
#define IDC_COMBO_SELECTION             1025
#define IDC_LOGO                        1026
#define ID_NEW_CIRCLE                   40001
#define ID_NEW_RANDOM                   40002
#define ID_APP_EMAIL                    40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
