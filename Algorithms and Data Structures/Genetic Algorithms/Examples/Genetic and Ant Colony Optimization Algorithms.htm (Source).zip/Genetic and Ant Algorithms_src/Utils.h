#pragma once
#include "Color.h"
//#include "AutoFont.h"
#include <math.h>
#include "PerfTimer.h"
#include "AutoFont.h"


int	  RandomInteger(int x,int y);
double RandomFloat();
bool   RandBool();



enum ViewMode{vmTour,vmGraph,vmAll};
enum PlotMode {pmCircular,pmRandom};

class CGlobals
{
public:
	
	static int WIN_WIDTH;
	static int WIN_HEIGHT;	
	static CPerfTimer TIMER;
	static long INFINITY;
	static double EPSILON;
	static double PI;
};

extern CAutoFont gFont;
//extern CPerfTimer Timer;
