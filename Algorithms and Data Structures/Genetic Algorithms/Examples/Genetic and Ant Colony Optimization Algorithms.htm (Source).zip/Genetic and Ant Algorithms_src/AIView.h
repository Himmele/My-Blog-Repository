#pragma once

#include "KCSideBannerWnd.h"
class CAIView : public CView
{
protected: // create from serialization only
	CAIView();
	DECLARE_DYNCREATE(CAIView)

// Attributes
public:
	CAIDoc* GetDocument() const;

// Operations
public:
  CButton* _buttonStart;
  CButton* _buttonStop;
  CButton* _buttonStep;
  CButton* _buttonReset;
  CButton* _buttonOptions;

  int _buttonWidth;
  int _buttonHeight;
  bool _isRunning;
  bool _isStepping;

 
  CKCSideBannerWnd _banner;


private:
	
// Overrides
	public:

virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CAIView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	 virtual void ButtonStart();
	virtual  void ButtonStop();
	virtual void ButtonStep();
	virtual void ButtonReset();
	virtual void ButtonOptions();
	afx_msg void OnSize(UINT nType, int cx, int cy);	
	afx_msg void OnPaint();
protected:
//	virtual void OnDraw(CDC* /*pDC*/);
	virtual void OnDraw(CDC* /*pDC*/);
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};

#ifndef _DEBUG  // debug version in ButtonDemoView.cpp
inline CAIDoc* CAIView::GetDocument() const
   { return reinterpret_cast<CAIDoc*>(m_pDocument); }
#endif

