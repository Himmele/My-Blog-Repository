// ButtonDemoDoc.h : interface of the CAIDoc class
//


#pragma once

class CAIDoc : public CDocument
{
protected: // create from serialization only
	CAIDoc();
	DECLARE_DYNCREATE(CAIDoc)

// Attributes
public:

// Operations
public:
	BOOL SwitchToView(CRuntimeClass* pNewViewClass);

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CAIDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual void SetTitle(LPCTSTR lpszTitle);
};


