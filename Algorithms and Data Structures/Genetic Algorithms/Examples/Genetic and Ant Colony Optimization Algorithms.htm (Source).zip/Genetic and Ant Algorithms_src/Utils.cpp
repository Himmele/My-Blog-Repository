#include "StdAfx.h"
#include "utils.h"


int CGlobals::WIN_WIDTH = 800;
int CGlobals::WIN_HEIGHT = 600;
double CGlobals::EPSILON = 0.005;
long CGlobals::INFINITY=999999;
double CGlobals::PI= 3.1412;
CPerfTimer CGlobals::TIMER; 

//returns a random integer between x and y
 int	  RandomInteger(int x,int y)
{
	//srand( (unsigned)time( NULL ) );
	return rand()%(y-x+1)+x;
}

//returns a random float between zero and 1
 double RandomFloat()
{
	return (rand())/(RAND_MAX+1.0);
}

//returns a random bool
inline bool   RandBool()
{
	if (RandomInteger(0,1))
		return true;

	else return false;
}

CAutoFont gFont;