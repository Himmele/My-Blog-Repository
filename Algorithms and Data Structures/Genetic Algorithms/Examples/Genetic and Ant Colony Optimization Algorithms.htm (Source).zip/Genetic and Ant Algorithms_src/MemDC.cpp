#include "StdAfx.h"
#include "MemDC.h"

void DrawCircle(CMemDC *pDC,int x,int y,int radius)
{
	pDC->Ellipse(x-radius,y-radius,x+radius,y+radius);
	
}