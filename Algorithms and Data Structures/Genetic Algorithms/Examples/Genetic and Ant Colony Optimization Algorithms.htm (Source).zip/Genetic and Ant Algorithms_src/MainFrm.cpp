// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "AIDemo.h"

#include "MainFrm.h"
#include "AIDoc.h"
#include "ACO/AcoView.h"
#include "GA/GAView.h"
#include "Utils.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace ACO;
using namespace GA;
extern CAutoFont gFont;
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_ALGORITHM_ANTCOLONYOPTIMISATION, OnAlgorithmAntcolonyoptimisation)
	ON_COMMAND(ID_ALGORITHM_GENETIC, OnAlgorithmGenetic)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	gFont.SetFaceName("Verdana");
}

CMainFrame::~CMainFrame()
{
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	CSize size;
	size.cx = GetSystemMetrics(SM_CXSCREEN);
	size.cy = GetSystemMetrics(SM_CYSCREEN);

    cs.x = (size.cx - size.cx/2)/2;
	cs.y = (size.cy - size.cy/2)/2;
	cs.cx = size.cx/2;
	cs.cy = size.cy/2;
	
	CRect rect;
	

	//cs.style &= ~(LONG) FWS_ADDTOTITLE;
	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers


void CMainFrame::OnAlgorithmAntcolonyoptimisation()
{
	// TODO: Add your command handler code here
	CAIDoc* pCurrentDoc = (CAIDoc*)(this->GetActiveDocument());
	pCurrentDoc->SwitchToView(RUNTIME_CLASS(CACOView));


}

void CMainFrame::OnAlgorithmGenetic()
{
	// TODO: Add your command handler code here
	CAIDoc* pCurrentDoc = (CAIDoc*)(this->GetActiveDocument());
	pCurrentDoc->SwitchToView(RUNTIME_CLASS(CGAView));
}
