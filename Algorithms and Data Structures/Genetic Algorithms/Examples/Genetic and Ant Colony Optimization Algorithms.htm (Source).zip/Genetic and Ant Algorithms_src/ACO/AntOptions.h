#pragma once
#include "afxwin.h"
#include "../Resource.h"
namespace ACO{
// CAntOptions dialog

class CAntOptions : public CDialog
{
	DECLARE_DYNAMIC(CAntOptions)

public:
	CAntOptions(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAntOptions();

// Dialog Data
	enum { IDD = IDD_ANTOPTIONS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CEdit txtAntNo;
	CEdit txtCityNo;
	CEdit txtAlpha;
	CEdit txtBeta;
	CEdit txtRho;
	
	CButton optVMTour;	
	CButton optVMTourGraph;
};
}//namespace