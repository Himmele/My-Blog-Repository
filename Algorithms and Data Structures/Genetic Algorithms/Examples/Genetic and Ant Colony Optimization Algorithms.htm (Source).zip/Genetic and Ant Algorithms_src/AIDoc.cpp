// ButtonDemoDoc.cpp : implementation of the CAIDoc class
//

#include "stdafx.h"
#include "AIDemo.h"
#include "AIDoc.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAIDoc

IMPLEMENT_DYNCREATE(CAIDoc, CDocument)

BEGIN_MESSAGE_MAP(CAIDoc, CDocument)
END_MESSAGE_MAP()


// CAIDoc construction/destruction

CAIDoc::CAIDoc()
{
	// TODO: add one-time construction code here

}

CAIDoc::~CAIDoc()
{
}

BOOL CAIDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

BOOL CAIDoc::SwitchToView(CRuntimeClass* pNewViewClass)
{
   CFrameWnd* pMainWnd = (CFrameWnd*)AfxGetMainWnd();
   CView* pOldActiveView = pMainWnd->GetActiveView();

   // If we're already displaying this kind of view, no need to go further.
  // if (pOldActiveView->IsKindOf(pNewViewClass))
     // return TRUE;
	
   // Set the child window ID of the active view to AFX_IDW_PANE_FIRST.
   // This is necessary so that CFrameWnd::RecalcLayout will allocate
   // this "first pane" to that portion of the frame window's client
   // area not allocated to control bars.  Set the child ID of
   // the previously active view to some other ID.
   ::SetWindowLong(pOldActiveView->m_hWnd, GWL_ID, 0);

   // create the new view
   CCreateContext context;
   context.m_pNewViewClass = pNewViewClass;
   context.m_pCurrentDoc = this;
   CView* pNewView = STATIC_DOWNCAST(CView, pMainWnd->CreateView(&context));
   if (pNewView != NULL)
   {
      // the new view is there, but invisible and not active...
      pNewView->ShowWindow(SW_SHOW);
      pNewView->OnInitialUpdate();
      pMainWnd->SetActiveView(pNewView);
      pMainWnd->RecalcLayout();

      // destroy the old view...
      pOldActiveView->DestroyWindow();
      return TRUE;
  }

  return FALSE;
}



// CAIDoc serialization

void CAIDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CAIDoc diagnostics

#ifdef _DEBUG
void CAIDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAIDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CAIDoc commands

void CAIDoc::SetTitle(LPCTSTR lpszTitle)
{
	//Set the title
	CFrameWnd* pWnd = (CFrameWnd*)AfxGetMainWnd();		
	CString csTitle; 
	//csTitle.LoadString(IDS_CUSTINFO_TITLE); 

	if ( CString(lpszTitle) == CString(_T("Untitled")) ) 
	{ 
		if (pWnd) 
			pWnd->SetWindowText((LPCTSTR)(csTitle)); 
	} 
	else 
	{ 
		csTitle = csTitle + _T(" - ") + lpszTitle; 
		if (pWnd) 
			pWnd->SetWindowText((LPCTSTR)(csTitle)); 
	} 

}
