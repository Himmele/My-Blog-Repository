#include "stdafx.h"
#include "GAConstants.h"
namespace GA {

	CGAConstants::CGAConstants(int CityNo,double MutationRate,double CrossOver,int PopSize,int CitSize)
	{
		this->NUM_CITES=18;
		this->MUTATION_RATE=0.2;
		this->CROSSOVER_RATE=0.75;
		this->POP_SIZE=10;
		this->EPSILON=0.005;
		this->CITY_SIZE=5;
		this->VM = vmAll;
		this->PM = pmCircular;
	}
	CGAConstants gGAConstants;
}//namespace