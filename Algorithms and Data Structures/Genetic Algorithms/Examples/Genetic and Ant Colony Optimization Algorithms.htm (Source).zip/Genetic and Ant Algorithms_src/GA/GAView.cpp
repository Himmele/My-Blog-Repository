// NeuroACO.cpp : implementation file
//

#include "stdafx.h"
#include "../AIDemo.h"
#include "../MemDC.h"
#include "../AIDoc.h"
#include "../Color.h"
#include "GAView.h"
#include "GAConstants.h"
#include "GAOptions.h"

namespace GA
{
	// CNeuroACO
	extern CGAConstants gGAConstants;
	IMPLEMENT_DYNCREATE(CGAView, CAIView)
		BEGIN_MESSAGE_MAP(CGAView, CAIView)
			ON_WM_PAINT()
			ON_WM_SIZE()
			ON_WM_TIMER()
		END_MESSAGE_MAP()

		CGAView::CGAView()
	{
		gaSystem=new CGASystem(gGAConstants.NUM_CITES,gGAConstants.MUTATION_RATE,
			gGAConstants.CROSSOVER_RATE,gGAConstants.POP_SIZE);
		//gaSystem->Run();
		//gaSystem->CreateStartingPopulation();
		graph=NULL;

		CGlobals::TIMER.Start(TRUE);
		CGlobals::TIMER.Stop();

		//Set Title
		//Set the title
		CFrameWnd* pMainWnd = (CFrameWnd*)AfxGetMainWnd();		
		if(pMainWnd)
		 pMainWnd->SetTitle("Gentic Algorithm");

		


	}

	CGAView::~CGAView()
	{
		delete gaSystem;
		delete graph;
	}

	void CGAView::ButtonStart()
	{
		CAIView::ButtonStart();
		gaSystem->_ProblemSolved=false;
	}
	//-------------------------------------------------
	//  
	//-------------------------------------------------
	void CGAView::ButtonStep()
	{
		CAIView::ButtonStep();
		if(gGAConstants.VM==vmAll)
		{
			InvalidateRect(&rectTour);
		}
		else 
		{
			InvalidateRect(&rectClient);
		}

	}

	void CGAView::ButtonStop()
	{
		CAIView::ButtonStop();
	}

	void CGAView::ButtonReset()
	{
		//CAIView::ButtonReset();

		CFrameWnd* pMainWnd = (CFrameWnd*)AfxGetMainWnd();		
		CView* pOldActiveView = pMainWnd->GetActiveView();

		//CAIDoc* pCurrentDoc = (CAIDoc*)(this->GetActiveDocument());
		CAIDoc* pCurrentDoc = (CAIDoc*)pOldActiveView->GetDocument();
		pCurrentDoc->SwitchToView(RUNTIME_CLASS(CGAView));

	}

	void CGAView::ButtonOptions()
	{
		CAIView::ButtonOptions();
		CGAOptions gaOpts;
		gaOpts.DoModal();
	}







	// CNeuroACO message handlers


	void CGAView::OnPaint()
	{
		CPaintDC dc(this); // device context for painting
		// TODO: Add your message handler code here
		// Do not call CAIView::OnPaint() for painting messages
		CMemDC memDC(&dc);
		//memDC.TextOut(10,10,"GAView");		

		if(gGAConstants.VM==vmTour)
		{
			//graph->DestroyWindow();
			//graph->Detach();
			delete graph;
			graph = NULL;
			gaSystem->AttachGraph(graph);
		}

		gaSystem->Render(&memDC);		        
	}

	//-------------------------------------------------
	// UpdateView 
	//-------------------------------------------------
	void CGAView::UpdateView()
	{
		//double ElapsedTime = 0;
		if(gaSystem->_ProblemSolved!=TRUE)
		{
		CGlobals::TIMER.Start(FALSE);
		gaSystem->Epoch();
		CGlobals::TIMER.Stop();
		gaSystem->_ElapsedTime=CGlobals::TIMER.Elapsedms();
		//}

		if(gGAConstants.VM==vmAll)
		{
			InvalidateRect(&rectTour,false);
			graph->Invalidate();
		}
		else 
		{
			InvalidateRect(&rectClient,false);
		}

		}//Problem not yet solved
		else
		{
			CAIView::_isRunning=false;
			CAIView::_isStepping=false;
		}

	}

	//-------------------------------------------------
	// OnSize 
	//-------------------------------------------------
	void GA::CGAView::OnSize(UINT nType, int cx, int cy)
	{
		CAIView::OnSize(nType, cx, cy);
		if(cx == 0 || cy==0)
			return;

		//Here we calculate the rectangles	
		this->GetClientRect(&rectClient);

		rectClient.DeflateRect(50,0,70,0);
		
		//calucate the top rectangle rectTour
		rectTour.left= rectClient.left;
		rectTour.top = rectClient.top;

		rectTour.right=rectClient.right;
		rectTour.bottom= (rectClient.bottom-rectClient.top)/2;
		//rectTour.DeflateRect(0,0,70,0);

		//calculate bottom rectange rectGraph
		rectGraph.left= rectClient.left;
		rectGraph.top = (rectClient.bottom-rectClient.top)/2;

		rectGraph.right= rectClient.right;
		rectGraph.bottom= rectClient.bottom;
		//rectGraph.DeflateRect(0,0,0,0);

		if(gGAConstants.VM == vmAll)
		{
			if(graph != NULL)
			{	

				
				graph->DestroyWindow();
				graph->Detach();
				delete graph;
				graph = NULL;
				graph = new CChart();
				graph->Create(WS_VISIBLE|WS_CHILD,rectGraph,this,12000);	
				//graph->MoveWindow(&rectGraph,true);
				//graph->SetWindowPos(this,100,rectGraph.top,rectGraph.Width(),rectGraph.Height(),SWP_SHOWWINDOW);
				gaSystem->AttachGraph(graph);
				CustomiseGraph();

				//graph->Invalidate(false);
				//graph->ShowWindow(SW_NORMAL);
			}
			else
			{
				graph = new CChart;
				graph->Create(WS_VISIBLE|WS_CHILD,rectGraph,this,12000);	
				gaSystem->AttachGraph(graph);
				CustomiseGraph();

			}			
			gaSystem->Resize(rectTour);
		}
		else if(gGAConstants.VM==vmTour)
		{
			
			if(graph!=NULL)
			{

				_isRunning=false;
				_isStepping=false;
				graph->DestroyWindow();
				graph->Detach();
				delete graph;
				graph = NULL;
				gaSystem->AttachGraph(graph);
				
				
			}
			if(graph==NULL)
			{
			gaSystem->Resize(rectClient);
			}
			//this->Invalidate();
			//gaSystem->Init(rectClient);
			
		}



		//Invalidate();
	}


	//-------------------------------------------------
	// OnTimer 
	//-------------------------------------------------
	void CGAView::OnTimer(UINT nIDEvent)
	{
		// TODO: Add your message handler code here and/or call default

		if(_isRunning)
		{
			UpdateView();	  
		}

		if(_isStepping)
		{
			UpdateView();
			_isStepping = false;
		}

		CView::OnTimer(nIDEvent);
	}

	//-------------------------------------------------
	// OnInitialUpdate 
	//-------------------------------------------------
	void CGAView::OnInitialUpdate()
	{
		CAIView::OnInitialUpdate();
	}

	//-------------------------------------------------
	// CustomiseGraph 
	//-------------------------------------------------
	void CGAView::CustomiseGraph()
	{
		graph->SetChartTitle("Genetic Algorithm Stats");
		graph->SetChartLabel("","Total Distance");
		graph->m_BGColor=CColor::white;
		graph->SetGridXYNumber(1,1);
		graph->SetAxisStyle(0);
		graph->nSerieCount=2;
		graph->AllocSerie(10000);

		graph->SetRange(0,1000,0,10000);
		graph->mpSerie[0].m_plotColor=CColor::blue;
		graph->mpSerie[1].m_plotColor=CColor::green;
	}
}//namespace