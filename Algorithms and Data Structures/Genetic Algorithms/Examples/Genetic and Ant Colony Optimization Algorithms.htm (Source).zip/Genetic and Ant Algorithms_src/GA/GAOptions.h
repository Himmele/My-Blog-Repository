#pragma once
#include "../Resource.h"
#include "afxwin.h"
namespace GA{
// CGAOptions dialog

class CGAOptions : public CDialog
{
	DECLARE_DYNAMIC(CGAOptions)

public:
	CGAOptions(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGAOptions();

// Dialog Data
	enum { IDD = IDD_GAOPTIONS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CEdit txtCityNo;
	CEdit txtCrossRate;
	CEdit txtMuteRate;
	CEdit txtPopSize;
	CButton optTour;	
	CButton optTourGraph;
};
}//namepace
