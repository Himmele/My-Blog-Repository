#pragma once

#include "../AIView.h"
#include "../Chart.h"
#include "GASystem.h"
namespace GA
{
// CNeuroACO

class CGAView : public CAIView
{
	DECLARE_DYNCREATE(CGAView)
public:
	void ButtonStart();
	void ButtonStop();
	void ButtonStep();
	void ButtonReset();
	void ButtonOptions();
	void UpdateView();

	//Rectangles for views
	//Rectangles
	CRect rectTour;
	CRect rectGraph;
	CRect rectClient;
	CChart* graph;

	void CustomiseGraph();

	CGASystem* gaSystem;
	bool ProblemSolved;

public:
	CGAView();
	virtual ~CGAView();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnInitialUpdate();
};

}//namespace
