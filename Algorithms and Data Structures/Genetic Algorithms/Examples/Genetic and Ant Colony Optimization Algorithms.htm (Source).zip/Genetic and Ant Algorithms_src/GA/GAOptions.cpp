// GAOptions.cpp : implementation file
//

#include "stdafx.h"
#include "../AIDoc.h"
#include "GAOptions.h"
#include "GAConstants.h"
#include "GAView.h"

namespace GA{
// CGAOptions dialog
extern CGAConstants gGAConstants;

IMPLEMENT_DYNAMIC(CGAOptions, CDialog)
CGAOptions::CGAOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CGAOptions::IDD, pParent)
{
}

CGAOptions::~CGAOptions()
{
}

void CGAOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_GAEDITCITYNO, txtCityNo);
	DDX_Control(pDX, IDC_GAEDITCROSS, txtCrossRate);
	DDX_Control(pDX, IDC_GAEDITMUTATION, txtMuteRate);
	DDX_Control(pDX, IDC_GAEDITPOPSIZE, txtPopSize);
	DDX_Control(pDX, IDC_RADIOVMTOUR, optTour);
	DDX_Control(pDX, IDC_RADIOVMTOURGRAPH, optTourGraph);
	//MyDDX
	char buffer[100];

	itoa(gGAConstants.NUM_CITES,buffer,10);
    txtCityNo.SetWindowText(buffer);

	sprintf(buffer,"%.4f",gGAConstants.CROSSOVER_RATE);
	txtCrossRate.SetWindowText(buffer);

	sprintf(buffer,"%.4f",gGAConstants.MUTATION_RATE);
	txtMuteRate.SetWindowText(buffer);

	itoa(gGAConstants.POP_SIZE,buffer,10);
	txtPopSize.SetWindowText(buffer);

	//Now for option buttons
	if(gGAConstants.VM == vmAll)
		optTourGraph.SetCheck(BST_CHECKED);

	if(gGAConstants.VM == vmTour)
		optTour.SetCheck(BST_CHECKED);

}


BEGIN_MESSAGE_MAP(CGAOptions, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()

void CGAOptions::OnBnClickedOk()
{
    char buffer[100];
	txtCityNo.GetLine(0,buffer,100);
	gGAConstants.NUM_CITES = atoi(buffer);

	char* endString;
	txtCrossRate.GetLine(0,buffer,100);
	gGAConstants.CROSSOVER_RATE = strtod(buffer,&endString);

	txtMuteRate.GetLine(0,buffer,100);
	gGAConstants.MUTATION_RATE=strtod(buffer,&endString);

	txtPopSize.GetLine(0,buffer,100);
	gGAConstants.POP_SIZE=atoi(buffer);

	if(optTourGraph.GetState()==1)
		gGAConstants.VM = vmAll;

	if(optTour.GetState()==1)
		gGAConstants.VM = vmTour;

	//Switch the main view
	CFrameWnd* pMainWnd = (CFrameWnd*)AfxGetMainWnd();
	CView* pOldActiveView = pMainWnd->GetActiveView();	
	CAIDoc* pCurrentDoc = (CAIDoc*)pOldActiveView->GetDocument();
	pCurrentDoc->SwitchToView(RUNTIME_CLASS(CGAView));
	OnOK();
}

// CGAOptions message handlers
}//namespace