#pragma once
#include "../Utils.h"
namespace GA
{
#ifndef __GACONST_H                                               
#define __GACONST_H
	//-----------------------------------
	//enum ViewMode{vmTour,vmGraph,vmAll};
	//enum PlotMode {pmCircular,pmRandom};
	class CGAConstants
	{
	public:
		CGAConstants(int CityNo =12,double MutationRate = 0.01,double CrossOver=0.75,int PopSize=30,int CitySize=5);
		int NUM_CITES;
		double MUTATION_RATE;
		double CROSSOVER_RATE;
		int POP_SIZE;
		double EPSILON;
		int CITY_SIZE;
		

		ViewMode VM;
		PlotMode PM;

	};

	//-----------------------------------

#endif
}//namespace
