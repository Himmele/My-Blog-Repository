//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AIDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ButtonDemoTYPE              129
#define IDD_ANTOPTIONS                  130
#define IDD_GAOPTIONS                   131
#define IDC_EDITCITYNO                  1001
#define IDC_EDITANTNO                   1006
#define IDC_EDITALPHA                   1007
#define IDC_EDITBETA                    1008
#define IDC_EDITRHO                     1009
#define IDC_RADIOVMTOUR                 1026
#define IDC_RADIOVMGRAPH                1027
#define IDC_RADIOVMTOURGRAPH            1028
#define IDC_GAEDITCITYNO                1030
#define IDC_GAEDITCROSS                 1031
#define IDC_GAEDITMUTATION              1032
#define IDC_GAEDITPOPSIZE               1033
#define ID_ALGORITHM_GENETIC            32771
#define ID_ALGORITHM_ANTCOLONYOPTIMISATION 32772
#define ID_ALGORITHM_NEUROANT           32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
