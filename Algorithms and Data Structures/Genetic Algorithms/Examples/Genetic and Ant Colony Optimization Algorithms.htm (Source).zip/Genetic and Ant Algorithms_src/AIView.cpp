// ButtonDemoView.cpp : implementation of the CAIView class
//

#include "stdafx.h"
#include "AIDemo.h"

#include "AIDoc.h"
#include "AIView.h"
#include "MemDC.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define BTN_START WM_USER+1
#define BTN_STOP WM_USER+2
#define BTN_STEP WM_USER+3
#define BTN_RESET WM_USER+4
#define BTN_OPTIONS WM_USER+5

// CAIView

IMPLEMENT_DYNCREATE(CAIView, CView)

BEGIN_MESSAGE_MAP(CAIView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_WM_CREATE()
	ON_BN_CLICKED(BTN_START,ButtonStart)
	ON_BN_CLICKED(BTN_STOP,ButtonStop)
	ON_BN_CLICKED(BTN_STEP,ButtonStep)
	ON_BN_CLICKED(BTN_RESET,ButtonReset)
	ON_BN_CLICKED(BTN_OPTIONS,ButtonOptions)
	ON_WM_SIZE()	
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

// CAIView construction/destruction

CAIView::CAIView()
{
	// TODO: add construction code here
    _isRunning = false;
	_isStepping = false;
	

}

CAIView::~CAIView()
{
	delete _buttonStart;
	delete _buttonStop;
	delete _buttonStep;
	delete  _buttonOptions;
	delete _buttonReset;
	
}

BOOL CAIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}




// CAIView printing

BOOL CAIView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CAIView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CAIView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CAIView diagnostics

#ifdef _DEBUG
void CAIView::AssertValid() const
{
	CView::AssertValid();
}

void CAIView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAIDoc* CAIView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAIDoc)));
	return (CAIDoc*)m_pDocument;
}
#endif //_DEBUG


// CAIView message handlers

void CAIView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	// TODO: Add your specialized code here and/or call the base class
	
   // Create a push button.
   _buttonWidth=70;
   _buttonHeight=25;

   _banner.Attach(this,KCSB_ATTACH_LEFT);
   _banner.SetTitle("Applications of AI");
   _banner.SetCaption("Peter Kohout  ");
   _banner.SetSize(50);
}

int CAIView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here


	_buttonStart=new CButton();
	_buttonStart->Create(_T("Start"), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_FLAT, 
		CRect(50,50,100,100), this, BTN_START);

	_buttonStop=new CButton();
	_buttonStop->Create(_T("Stop"), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_FLAT, 
		CRect(50,50,100,100), this, BTN_STOP);

	_buttonStep=new CButton();
	_buttonStep->Create(_T("Step"), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_FLAT, 
		CRect(50,50,100,100), this, BTN_STEP);

	_buttonReset=new CButton();
	_buttonReset->Create(_T("Reset"), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_FLAT, 
		CRect(50,50,100,100), this, BTN_RESET);

	_buttonOptions=new CButton();
	_buttonOptions->Create(_T("Options"), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_FLAT, 
		CRect(50,50,100,100), this, BTN_OPTIONS);


	_buttonStop->EnableWindow(false);
    SetTimer(1,1,0);
	

	//_button->Invalidate(1);
	//_button->ShowWindow(SW_SHOWNORMAL);
	return 0;
}

void CAIView::ButtonStart()
{
  //MessageBox("Start Button Pressed");
 
  _buttonStop->EnableWindow(true);
  _buttonStart->EnableWindow(false);
  _buttonOptions->EnableWindow(false);
  _isRunning = true;
  _isStepping=false;
  //SetTimer(1,1,0);
}

void CAIView::ButtonStop()
{
   //KillTimer(1);
   _buttonStop->EnableWindow(false);
  _buttonStart->EnableWindow(true);
  _buttonOptions->EnableWindow(true);
  _isRunning = false;
  
 

}

void CAIView::ButtonStep()
{
 
  //SetTimer(1,1,0); 
  _isStepping = true;
}


void CAIView::ButtonReset()
{
 //KillTimer(1);
	 _isRunning=false;
	_isStepping=false;
	_buttonStart->EnableWindow(true);
	 _buttonStop->EnableWindow(false);
	
}


void CAIView::ButtonOptions()
{
   _isRunning=false;
   _isStepping=false;
   _buttonStop->EnableWindow(false);
   _buttonStart->EnableWindow(true);
   _buttonOptions->EnableWindow(true);
    //KillTimer(1);
}
void CAIView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	CRect rect;
	GetClientRect(&rect);	
	_buttonStart->MoveWindow(rect.right - _buttonWidth,2,_buttonWidth,_buttonHeight);
	_buttonStop->MoveWindow(rect.right - _buttonWidth,_buttonHeight ,_buttonWidth,_buttonHeight);
	_buttonStep->MoveWindow(rect.right - _buttonWidth,2*_buttonHeight,_buttonWidth,_buttonHeight);
	_buttonReset->MoveWindow(rect.right - _buttonWidth,3*_buttonHeight,_buttonWidth,_buttonHeight);
	_buttonOptions->MoveWindow(rect.right - _buttonWidth,7*_buttonHeight,_buttonWidth,_buttonHeight);
    _banner.UpdateSize();
}





void CAIView::OnPaint()
{
	//CPaintDC dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CView::OnPaint() for painting messages
	//CMemDC memDC(&dc);

	//char buffer[400];
	//sprintf(buffer,"Count = %d",_counter);	
	//TextOut(memDC.m_hDC,10,10,buffer,strlen(buffer));
}


void CAIView::OnDraw(CDC* pDC)
{
	// TODO: Add your specialized code here and/or call the base class
	//char buffer[20];
	//sprintf(buffer,"Count = %d",_counter);
	//pDC->TextOut(10,10,buffer,strlen(buffer));
}

BOOL CAIView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: Add your message handler code here and/or call default

	return FALSE;
}
